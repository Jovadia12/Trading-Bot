import sys
import numpy as np
import pandas as pd

sys.path.insert(0, "/home/claude/spotlab")
from lab import simulate, ema, rsi, atr   # validated simulator (worst-case fills) and indicators

TFS = ["15min", "30min", "1h", "2h", "4h", "1D"]
HOURS = {"15min": .25, "30min": .5, "1h": 1, "2h": 2, "4h": 4, "1D": 24}
SOL = 117.0
# per side: platform fee, pool fee, slippage, fixed USD per swap
COSTS = {
    "zero": (0, 0, 0, 0),
    "axiom_best": (0.0085, 0.0002, 0.0002, 0.0005 * SOL),
    "axiom_normal": (0.0095, 0.0005, 0.0005, 0.002 * SOL),
    "axiom_conservative": (0.0100, 0.0010, 0.0010, 0.004 * SOL),
    "axiom_harsh": (0.0100, 0.0030, 0.0025, 0.01 * SOL),
    "coinbase_taker": (0.0090, 0.0, 0.0005, 0.0),
    "coinbase_maker_entry": None,   # entry maker 0.50% (limit), exit taker 0.90% + slippage
}
PRIMARY, SEL_NOTIONAL = "axiom_normal", 250.0
ROUND_TRIP_NORMAL = 0.022

FILTERS = {  # name -> (label, values)
    "F1": ("HTF trend: daily close > SMA{}", (100, 200)),
    "F2": ("ATR% >= median x{}", (1.0, 1.25)),
    "F3": ("SMA20 - close >= {} ATR", (1.5, 2.5)),
    "F4": ("expected move to SMA20 >= {}x round-trip cost", (1, 2)),
    "F5": ("volume >= {}x 20-bar avg", (1.5, 2.0)),
    "F6": ("RSI14 >= {} (long) / <= 100-{} (short)", (40, 50)),
    "F7": ("ATR% <= trailing {}th pct", (90, 75)),
}


def load(src, tf):
    return pd.read_pickle(f"data/{src}_{tf}.pkl")


def features(src, tf):
    df = load(src, tf)
    c = df.close
    x = pd.DataFrame(index=df.index)
    x["atr"] = atr(df)
    x["ema50"], x["ema200"] = ema(c, 50), ema(c, 200)
    x["sma5"], x["sma20"] = c.rolling(5).mean(), c.rolling(20).mean()
    x["rsi2"], x["rsi14"] = rsi(c, 2), rsi(c, 14)
    x["atrp"] = x.atr / c
    x["atrp_med"] = x.atrp.rolling(500, min_periods=200).median()
    x["atrp_q90"] = x.atrp.rolling(500, min_periods=200).quantile(0.90)
    x["atrp_q75"] = x.atrp.rolling(500, min_periods=200).quantile(0.75)
    x["vol_avg"] = df.volume.rolling(20).mean()
    # daily trend known at this bar's close: last daily candle that has closed by then
    d = load(src, "1D").close
    dd = pd.DataFrame({"dclose": d, "sma100": d.rolling(100).mean(), "sma200": d.rolling(200).mean()})
    dd["avail"] = dd.index + pd.Timedelta(days=1)
    bar_close = df.index + pd.Timedelta(hours=HOURS[tf])
    m = pd.merge_asof(pd.DataFrame({"bc": bar_close}), dd.reset_index(drop=True).sort_values("avail"),
                      left_on="bc", right_on="avail", direction="backward")
    for col in ("dclose", "sma100", "sma200"):
        x[col] = m[col].values
    return df, x


def masks(df, x, side):
    """Base entry, exit variants, and every filter mask for one side (1 long, -1 short research)."""
    c, up = df.close, side == 1
    gt = (lambda a, b: a > b) if up else (lambda a, b: a < b)
    base = gt(c, x.ema200) & gt(x.ema50, x.ema200) & ((x.rsi2 < 10) if up else (x.rsi2 > 90))
    dist = (x.sma20 - c) * side                     # distance to mean in the profitable direction
    f = {}
    for v in (100, 200):
        f[("F1", v)] = gt(x.dclose, x[f"sma{v}"])
    for v in (1.0, 1.25):
        f[("F2", v)] = x.atrp >= x.atrp_med * v
    for v in (1.5, 2.5):
        f[("F3", v)] = dist >= v * x.atr
    for v in (1, 2):
        f[("F4", v)] = dist / c >= v * ROUND_TRIP_NORMAL
    for v in (1.5, 2.0):
        f[("F5", v)] = df.volume >= v * x.vol_avg
    for v in (40, 50):
        f[("F6", v)] = (x.rsi14 >= v) if up else (x.rsi14 <= 100 - v)
    f[("F7", 90)] = x.atrp <= x.atrp_q90
    f[("F7", 75)] = x.atrp <= x.atrp_q75
    exits = {"X1": (gt(c, x.sma5), 10), "X2": (gt(c, x.sma20), 20)}
    valid = x.ema200.notna() & x.atrp_q90.notna() & x.sma200.notna() & x.vol_avg.notna()
    return (base & valid), exits, {k: v.fillna(False) for k, v in f.items()}


def run(df, x, entry, exit_sig, maxbars, side):
    ei, xi, er, xr, rd, xt = simulate(df.open.values, df.high.values, df.low.values, df.close.values,
                                      x.atr.values, entry.fillna(False).values, exit_sig.fillna(False).values,
                                      3.0, maxbars, False, side)
    t = pd.DataFrame(dict(entry_i=ei, exit_i=xi, entry_ref=er, exit_ref=xr, rdist=rd))
    t["entry_time"], t["exit_time"], t["side"] = df.index[ei], df.index[xi], side
    return t


def net(t, scenario, notional):
    """Net return per trade for a given position size (fixed network costs scale with 1/notional)."""
    s = t.side.values
    er, xr = t.entry_ref.values, t.exit_ref.values
    if scenario == "coinbase_maker_entry":
        buy = er * (1 + 0.0) ; fee_in, fee_out, sl, fx = 0.0050, 0.0090, 0.0005, 0.0
        e_px, x_px = er, xr * (1 - s * sl)
    else:
        fee, pool, sl, fx = COSTS[scenario]
        fee_in = fee_out = fee
        e_px = er * (1 + s * (sl + pool))
        x_px = xr * (1 - s * (sl + pool))
    n = np.broadcast_to(np.asarray(notional, float), s.shape)
    long_ret = (x_px / e_px) * (1 - fee_in) * (1 - fee_out) - 1 - 2 * fx / n
    short_ret = (1 - x_px / e_px) - fee_in - fee_out - 2 * fx / n
    return np.where(s == 1, long_ret, short_ret)


def metrics(t, ret, years=None):
    n = len(ret)
    if n == 0:
        return dict(trades=0)
    w, lo = ret[ret > 0], ret[ret <= 0]
    streak = mx = 0
    for v in ret:
        streak = streak + 1 if v <= 0 else 0
        mx = max(mx, streak)
    tot = ret.sum()
    srt = np.sort(ret)[::-1]
    top = lambda p: srt[:max(1, int(np.ceil(n * p)))].sum() / tot if tot > 0 else np.nan
    hold = (t.exit_time - t.entry_time).dt.total_seconds().values / 3600
    return dict(trades=n, trades_per_year=n / years if years else np.nan, win_rate=len(w) / n,
                avg_win=w.mean() if len(w) else np.nan, avg_loss=lo.mean() if len(lo) else np.nan,
                win_loss_ratio=w.mean() / -lo.mean() if len(w) and len(lo) and lo.mean() < 0 else np.nan,
                expectancy=ret.mean(), profit_factor=w.sum() / -lo.sum() if lo.sum() < 0 else np.inf,
                max_consec_losses=mx, avg_hold_h=hold.mean(), top1=top(.01), top5=top(.05), top10=top(.10),
                tstat=ret.mean() / ret.std(ddof=1) * np.sqrt(n) if n > 2 and ret.std() > 0 else np.nan)


def account(t, scenario, closes, alloc, start=500.0, min_order=10.0):
    """Cash-only spot account. Position = alloc x available cash (never above cash). Hourly mark-to-market."""
    idx, cv = closes.index, closes.values
    eq = np.full(len(idx), np.nan)
    cash, last, fees_paid, skipped = start, 0, 0.0, 0
    a_i = idx.searchsorted(pd.DatetimeIndex(t.entry_time)); b_i = idx.searchsorted(pd.DatetimeIndex(t.exit_time))
    for k, (a, b) in enumerate(zip(a_i, b_i)):
        eq[last:a] = cash
        amt = cash * alloc
        if amt < min_order:
            skipped += 1; last = a; continue
        r = net(t.iloc[[k]], scenario, amt)[0]
        r0 = net(t.iloc[[k]], "zero", amt)[0]
        fees_paid += amt * (r0 - r)
        er = t.entry_ref.iloc[k]
        eq[a:b] = cash + amt * (cv[a:b] / er - 1) - amt * (r0 - r) / 2
        cash += amt * r
        last = b
    eq[last:] = cash
    s = pd.Series(eq, index=idx).ffill().fillna(start)
    d = s.resample("1D").last().dropna()
    dr = d.pct_change().dropna()
    return dict(final=d.iloc[-1], total_return=d.iloc[-1] / start - 1, max_dd=float((d / d.cummax() - 1).min()),
                sharpe=float(dr.mean() / dr.std() * np.sqrt(365)) if dr.std() > 0 else 0.0,
                costs_paid=fees_paid, skipped=skipped), s
