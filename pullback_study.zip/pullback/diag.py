import pickle, numpy as np, pandas as pd, plab
exec(open("run_wf.py").read().split("def ret(")[0])   # rebuild STORE only
pickle.dump(STORE, open("results/store.pkl","wb"))
a, b = pd.Timestamp("2018-03-01", tz="UTC"), pd.Timestamp("2025-01-01", tz="UTC")
rows=[]
for k,t in STORE.items():
    d=t[(t.entry_time>=a)&(t.entry_time<b)]
    if len(d)==0: rows.append(dict(tf=k[0],side=k[1],exit=k[2],filt=str(k[3]),trades=0)); continue
    z=plab.net(d,"zero",250); n=plab.net(d,"axiom_normal",250); bst=plab.net(d,"axiom_best",250)
    rows.append(dict(tf=k[0],side=k[1],exit=k[2],filt=str(k[3]),trades=len(d),per_yr=len(d)/6.83,
        win_zero=(z>0).mean(),exp_zero=z.mean(),avg_win_zero=z[z>0].mean(),win_net=(n>0).mean(),exp_net=n.mean(),
        pf_net=n[n>0].sum()/-n[n<=0].sum() if (n<=0).any() else np.inf, exp_best=bst.mean()))
D=pd.DataFrame(rows); D.to_csv("results/dev_landscape.csv",index=False)
pd.set_option("display.width",250); pd.set_option("display.max_rows",300)
L=D[D.side==1]
print("LONG base configs (dev 2018-03..2024, $250 position):")
print(L[L.filt=="BASE"].round(4).to_string(index=False))
print("\nLONG: best 12 configs by net expectancy under Axiom normal:")
print(L.sort_values("exp_net",ascending=False).head(12).round(4).to_string(index=False))
print("\nconfigs with PF_net>1:", (L.pf_net>1).sum(), " of", len(L), "| with >=30 trades & PF>1:", ((L.pf_net>1)&(L.trades>=30)).sum())
