import pandas as pd, glob
def build(pattern, pre):
    parts=[]
    for f in sorted(glob.glob(pattern)):
        d=pd.read_csv(f, usecols=[0,1,2,3,4,5]); d.columns=["t","open","high","low","close","volume"]
        d["t"]=pd.to_datetime(d.t, utc=True, format="ISO8601"); parts.append(d)
    m=pd.concat(parts).drop_duplicates("t").sort_values("t").set_index("t")
    for tf in ["15min","30min","1h","2h","4h","1D"]:
        a=m.resample(tf,label="left",closed="left").agg({"open":"first","high":"max","low":"min","close":"last","volume":"sum"}).dropna()
        a.to_pickle(f"data/{pre}_{tf}.pkl"); print(pre, tf, len(a))
build("/home/claude/data/m1/binance_*.csv.gz","binance"); build("/home/claude/data/m1/bitstamp_*.csv.gz","bitstamp")
