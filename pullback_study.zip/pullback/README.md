# High-win-rate pullback study (Axiom cost model)
Read PREREGISTRATION.md (protocol, verified costs, outcome). Requires the 1-minute data used in spotlab.
    pip install pandas numpy numba
    python build.py && python run_wf.py && python diag.py && python report.py
results/: dev_landscape.csv (every config pre/post cost), candidates_dev_by_cost.csv, accounts_500usd.csv,
versionA_axiom.csv, regimes_dev.csv, shorts_research.csv, walkforward_selections.csv
