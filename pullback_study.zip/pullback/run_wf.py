import pickle, time
import numpy as np, pandas as pd
import plab

TRAIN_START, DEV_END = pd.Timestamp("2018-03-01", tz="UTC"), pd.Timestamp("2025-01-01", tz="UTC")
FOLDS = [2020, 2021, 2022, 2023, 2024]
t0 = time.time()
DATA, STORE = {}, {}
for tf in plab.TFS:
    df, x = plab.features("binance", tf)
    DATA[tf] = (df, x)
    for side in (1, -1):
        base, exits, F = plab.masks(df, x, side)
        DATA[(tf, side)] = (base, exits, F)
        for ex, (esig, mb) in exits.items():
            STORE[(tf, side, ex, "BASE")] = plab.run(df, x, base, esig, mb, side)
            for fk, fm in F.items():
                STORE[(tf, side, ex, fk)] = plab.run(df, x, base & fm, esig, mb, side)
print("single configs:", len(STORE), round(time.time() - t0), "s")


def ret(t, scen=plab.PRIMARY):
    return plab.net(t, scen, plab.SEL_NOTIONAL)


def window(t, a, b):
    return t[(t.entry_time >= a) & (t.entry_time < b)]


def score(t):
    r = ret(t)
    if len(r) < 30: return None
    pf = r[r > 0].sum() / -r[r <= 0].sum() if (r <= 0).any() else np.inf
    if pf <= 1.0: return None
    return r.mean() / r.std(ddof=1) * np.sqrt(len(r))


def pair_key(tf, side, ex, a, b):
    return (tf, side, ex, ("PAIR", a, b))


def build_pairs(side, a, b):
    """Stage 2: per timeframe x exit, pair the two best single filters (different families) ranked on [a, b)."""
    made = []
    for tf in plab.TFS:
        base, exits, F = DATA[(tf, side)]
        df, x = DATA[tf]
        for ex, (esig, mb) in exits.items():
            ranked = []
            for fk in F:
                s = score(window(STORE[(tf, side, ex, fk)], a, b))
                if s is not None: ranked.append((s, fk))
            ranked.sort(reverse=True)
            picks = []
            for s, fk in ranked:
                if all(fk[0] != p[0] for p in picks): picks.append(fk)
                if len(picks) == 2: break
            if len(picks) == 2:
                k = pair_key(tf, side, ex, *picks)
                if k not in STORE:
                    STORE[k] = plab.run(df, x, base & F[picks[0]] & F[picks[1]], esig, mb, side)
                made.append(k)
    return made


def select(side, a, b, pool_pairs):
    best = None
    for k, t in STORE.items():
        if k[1] != side or (isinstance(k[3], tuple) and k[3][0] == "PAIR" and k not in pool_pairs): continue
        s = score(window(t, a, b))
        if s is not None and (best is None or s > best[0]): best = (s, k)
    return best


rows, oos = [], []
for side in (1, -1):
    for Y in FOLDS:
        a, b = TRAIN_START, pd.Timestamp(f"{Y}-01-01", tz="UTC")
        pairs = build_pairs(side, a, b)
        sel = select(side, a, b, set(pairs))
        # also the best config per timeframe (to show how each timeframe fares)
        for tf in plab.TFS + ["ANY"]:
            if tf == "ANY":
                cand = sel
            else:
                cand = None
                for k, t in STORE.items():
                    if k[0] != tf or k[1] != side or (isinstance(k[3], tuple) and k[3][0] == "PAIR" and k not in pairs): continue
                    s = score(window(t, a, b))
                    if s is not None and (cand is None or s > cand[0]): cand = (s, k)
            if cand is None:
                rows.append(dict(side=side, fold=Y, scope=tf, selected=None)); continue
            test = window(STORE[cand[1]], b, pd.Timestamp(f"{Y+1}-01-01", tz="UTC")).copy()
            test["scope"], test["fold"], test["key"] = tf, Y, str(cand[1])
            oos.append(test)
            rows.append(dict(side=side, fold=Y, scope=tf, selected=str(cand[1]), train_t=round(cand[0], 2), test_trades=len(test)))
pd.DataFrame(rows).to_csv("results/walkforward_selections.csv", index=False)
W = pd.concat(oos); W.to_pickle("results/walkforward_oos.pkl")
pickle.dump(STORE, open("results/store.pkl", "wb"))

out = []
for (side, scope), d in W.groupby(["side", "scope"]):
    for scen in ("zero", "axiom_best", "axiom_normal", "axiom_conservative", "axiom_harsh", "coinbase_taker", "coinbase_maker_entry"):
        m = plab.metrics(d, plab.net(d, scen, plab.SEL_NOTIONAL), years=5)
        out.append(dict(side="LONG" if side == 1 else "SHORT(research)", scope=scope, costs=scen, **m))
R = pd.DataFrame(out); R.to_csv("results/walkforward_oos_metrics.csv", index=False)
print("done", round(time.time() - t0), "s")
