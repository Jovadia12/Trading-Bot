import pickle, sys, numpy as np, pandas as pd, plab
sys.path.insert(0, "/home/claude/spotlab"); import lab
STORE = pickle.load(open("results/store.pkl", "rb"))
a, b = pd.Timestamp("2018-03-01", tz="UTC"), pd.Timestamp("2025-01-01", tz="UTC"); yrs = 6.84
SCEN = ["zero", "axiom_best", "axiom_normal", "axiom_conservative", "axiom_harsh", "coinbase_taker", "coinbase_maker_entry"]
closes = plab.load("binance", "1h").close; cl_dev = closes[(closes.index >= a) & (closes.index < b)]
def win(t, a, b): return t[(t.entry_time >= a) & (t.entry_time < b)].reset_index(drop=True)
CANDS = {f"{tf} base RSI2<10, exit X2": (tf, 1, "X2", "BASE") for tf in plab.TFS}
CANDS.update({"1D + F6 RSI14>=50, exit X2 (only net-positive long config)": ("1D", 1, "X2", ("F6", 50)),
              "4H + F4 move>=2x cost, exit X2": ("4h", 1, "X2", ("F4", 2)),
              "1D + F1 daily>SMA100, exit X1": ("1D", 1, "X1", ("F1", 100))})
rows, accts = [], []
for name, k in CANDS.items():
    t = win(STORE[k], a, b)
    for s in SCEN:
        m = plab.metrics(t, plab.net(t, s, 250), yrs); rows.append(dict(candidate=name, costs=s, **m))
    for al in (0.25, 0.5, 0.75, 1.0):
        r, _ = plab.account(t, "axiom_normal", cl_dev, al); accts.append(dict(candidate=name, period="dev 2018-03..2024", alloc=al, **r))
# Version A baseline on Axiom costs: dev + both holdouts
va_rows = []
for src, s0, s1, lbl in [("binance", "2018-03-01", "2025-01-01", "dev 2018-03..2024"),
                         ("binance", "2025-01-01", "2026-09-10", "H1 2025..2026-09"),
                         ("bitstamp", "2014-01-01", "2018-01-01", "H2 2014-2017")]:
    df = lab.load(src, "4h"); x = lab.indicators(df)
    t = lab.run_config(lab.VERSION_A, df, x)
    t = t[(t.entry_time >= pd.Timestamp(s0, tz="UTC")) & (t.entry_time < pd.Timestamp(s1, tz="UTC"))].reset_index(drop=True)
    y = (pd.Timestamp(s1) - pd.Timestamp(s0)).days / 365.25
    cl = plab.load(src, "1h").close; cl = cl[(cl.index >= pd.Timestamp(s0, tz="UTC")) & (cl.index < pd.Timestamp(s1, tz="UTC"))]
    for sc in ("zero", "axiom_normal", "axiom_harsh", "coinbase_taker"):
        va_rows.append(dict(candidate="Version A (4H)", period=lbl, costs=sc, **plab.metrics(t, plab.net(t, sc, 250), y)))
    for al in (0.25, 0.5, 0.75, 1.0):
        r, _ = plab.account(t, "axiom_normal", cl, al); accts.append(dict(candidate="Version A (4H)", period=lbl, alloc=al, **r))
    bh = cl.resample("1D").last(); accts.append(dict(candidate="BTC buy & hold", period=lbl, alloc=1.0, total_return=bh.iloc[-1]/bh.iloc[0]-1, max_dd=float((bh/bh.cummax()-1).min()), sharpe=float(bh.pct_change().mean()/bh.pct_change().std()*np.sqrt(365))))
# regimes for base daily + 4H (dev), axiom normal
d = plab.load("binance", "1D").close; sma = d.rolling(200).mean(); sl = sma - sma.shift(20)
reg = pd.Series(np.where((d > sma) & (sl > 0), "BULL", np.where((d < sma) & (sl < 0), "BEAR", "TRANSITION")), index=d.index)
rg = []
for name in ["4h base RSI2<10, exit X2", "1D base RSI2<10, exit X2", "1h base RSI2<10, exit X2"]:
    t = win(STORE[CANDS[name]], a, b); r0 = plab.net(t, "zero", 250); rn = plab.net(t, "axiom_normal", 250)
    g = [reg.asof(x - pd.Timedelta(days=1)) for x in t.entry_time]
    for G in ("BULL", "TRANSITION", "BEAR"):
        mk = np.array(g) == G
        if mk.sum(): rg.append(dict(candidate=name, regime=G, trades=int(mk.sum()), win_pre=(r0[mk] > 0).mean(), exp_pre=r0[mk].mean(), win_net=(rn[mk] > 0).mean(), exp_net=rn[mk].mean()))
# shorts (research): base configs
sh = []
for tf in plab.TFS:
    t = win(STORE[(tf, -1, "X2", "BASE")], a, b)
    for sc in ("zero", "axiom_normal"):
        sh.append(dict(tf=tf, costs=sc, **{k: v for k, v in plab.metrics(t, plab.net(t, sc, 250), yrs).items() if k in ("trades", "trades_per_year", "win_rate", "avg_win", "avg_loss", "expectancy", "profit_factor")}))
pd.DataFrame(rows).to_csv("results/candidates_dev_by_cost.csv", index=False)
pd.DataFrame(va_rows).to_csv("results/versionA_axiom.csv", index=False)
pd.DataFrame(accts).to_csv("results/accounts_500usd.csv", index=False)
pd.DataFrame(rg).to_csv("results/regimes_dev.csv", index=False)
pd.DataFrame(sh).to_csv("results/shorts_research.csv", index=False)
pd.set_option("display.width", 270); pd.set_option("display.max_rows", 300)
R = pd.DataFrame(rows)
print(R[R.costs.isin(["zero", "axiom_normal"])][["candidate", "costs", "trades", "trades_per_year", "win_rate", "avg_win", "avg_loss", "win_loss_ratio", "expectancy", "profit_factor", "max_consec_losses", "avg_hold_h", "top5", "top10"]].round(4).to_string(index=False))
print(R[R.candidate.str.startswith(("4h base", "1D base", "1D + F6"))].pivot_table(index="candidate", columns="costs", values="expectancy").round(4)[SCEN].to_string())
print(pd.DataFrame(va_rows).round(4)[["period", "costs", "trades", "win_rate", "avg_win", "avg_loss", "expectancy", "profit_factor", "max_consec_losses"]].to_string(index=False))
print(pd.DataFrame(accts).round(3).to_string(index=False))
print(pd.DataFrame(rg).round(4).to_string(index=False)); print(pd.DataFrame(sh).round(4).to_string(index=False))
